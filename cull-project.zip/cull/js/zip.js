/* Minimal store-only ZIP writer (no compression; photos are already compressed). */
(function(){
const CT=new Uint32Array(256).map((_,n)=>{for(let k=0;k<8;k++)n=n&1?0xEDB88320^n>>>1:n>>>1;return n>>>0});const crc=u=>{let c=-1;for(const b of u)c=CT[(c^b)&255]^c>>>8;return(c^-1)>>>0};
const makeZip=async files=>{const E=new TextEncoder(),parts=[],cen=[];let off=0;
 for(const f of files){const u=new Uint8Array(await f.arrayBuffer()),n=E.encode(f.name),c=crc(u),h=new DataView(new ArrayBuffer(30)),g=new DataView(new ArrayBuffer(46));
  h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint32(14,c,true);h.setUint32(18,u.length,true);h.setUint32(22,u.length,true);h.setUint16(26,n.length,true);parts.push(h,n,u);
  g.setUint32(0,0x02014b50,true);g.setUint16(4,20,true);g.setUint16(6,20,true);g.setUint32(16,c,true);g.setUint32(20,u.length,true);g.setUint32(24,u.length,true);g.setUint16(28,n.length,true);g.setUint32(42,off,true);cen.push(g,n);off+=30+n.length+u.length}
 const cs=cen.reduce((a,x)=>a+x.byteLength,0),e=new DataView(new ArrayBuffer(22));e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,cs,true);e.setUint32(16,off,true);
 return new Blob([...parts,...cen,e],{type:'application/zip'})};
if(typeof module!=='undefined')module.exports={makeZip};
else window.makeZip=makeZip;
})();
