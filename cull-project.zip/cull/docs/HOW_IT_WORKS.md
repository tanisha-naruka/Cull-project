# How Cull works

Everything runs in the browser tab. The only network call is to your own Ollama at `localhost`.

## Pipeline
1. **Decode and downscale.** Each photo is drawn to a canvas (256 px wide by default; 128 or 512 in Settings).
2. **Sharpness.** Variance of a 4-neighbour Laplacian over the luminance channel. Low variance means soft or motion-blurred. It is mapped to 0-1 on a log scale.
3. **Exposure.** Distance of mean brightness from mid-grey, minus a penalty for the share of crushed (<20) or blown (>240) pixels.
4. **Score.** `score = 100 * (w * sharpness + (1 - w) * exposure)`, with `w` set by the sharpness-weight slider (default 0.65).
5. **Bursts.** A 64-bit difference hash (dHash) from a 9x8 thumbnail. Photos within the chosen Hamming distance (default 10) form a burst, and only the highest-scoring frame stays eligible.
6. **First-pass decision.** Keep if score >= threshold (default 60) and not a burst loser; otherwise reject.
7. **Gemma review.** Photos within +/-15 points of the threshold (the "borderline band") are sent, downscaled to 768 px, to `POST {ollama}/api/generate` with the critique prompt. The last `KEEP` or `REJECT` in the reply becomes the final decision and overrides the score. Skipped silently if Ollama is not reachable.
8. **Human review and export.** Keyboard review, zoom and compare, then a ZIP of kept originals or a CSV of decisions and reasons.

## Files
| File | Role |
|---|---|
| `index.html` | Page shell, loads the scripts in order |
| `css/styles.css` | Styling |
| `js/app.js` | Router, page templates, components |
| `js/zip.js` | Store-only ZIP writer (unit tested) |
| `js/cull.js` | Analysis, scoring, bursts, Gemma review, settings, saved shoots, page overrides |
| `tests/` | `node --test` unit tests |

## Privacy
- Photos are read with the File API and shown through `blob:` URLs. They are never sent to a server.
- Saved shoots hold only a name, date, counts and a 240x160 thumbnail in `localStorage`.
- Gemma requests go only to the Ollama URL in Settings (default `http://localhost:11434`).

## Known limits
- JPG, PNG and WebP only. Export RAW previews first.
- Heuristic scores cannot see closed eyes or composition; that is Gemma's job, and a 4B model makes mistakes. Treat verdicts as suggestions.
- Accuracy has not been benchmarked against professional cullers.
- Photos are held in memory for the session. Reloading the page requires re-uploading.
