;(()=>{
window.DB={user:{name:'Photographer',email:''},set:{thr:60,wsh:65,gem:1,band:15,ham:10,dd:1,auto:1,res:256,url:'http://localhost:11434',model:'gemma3:4b',prompt:'You are a photo editor culling a shoot. In two sentences: are the eyes open, is the subject sharp, is the composition good? End with KEEP or REJECT.'},shoots:[],acct:null};
try{const x=JSON.parse(localStorage.cull),d=DB;Object.assign(d.user,x.user);Object.assign(d.set,x.set);d.shoots=x.shoots||[];d.acct=x.acct||null}catch{}
const sv=()=>{try{localStorage.cull=JSON.stringify(DB)}catch{}},esc=s=>String(s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');window.esc=esc;
const RL=window.RL={on:0,files:[],model:DB.set.model},cl=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),L=(d,i)=>.299*d[i]+.587*d[i+1]+.114*d[i+2];
async function an(f){
 const b=await createImageBitmap(f),w=DB.set.res,h=Math.max(8,Math.round(b.height*w/b.width)),c=document.createElement('canvas');c.width=w;c.height=h;
 const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(b,0,0,w,h);const d=x.getImageData(0,0,w,h).data,Y=new Float32Array(w*h);let m=0,e=0;
 for(let i=0;i<w*h;i++){const v=L(d,i*4);Y[i]=v;m+=v;if(v<20||v>240)e++}
 let s=0,s2=0,n=0;for(let y=1;y<h-1;y++)for(let q=1;q<w-1;q++){const i=y*w+q,l=4*Y[i]-Y[i-1]-Y[i+1]-Y[i-w]-Y[i+w];s+=l;s2+=l*l;n++}
 const g=document.createElement('canvas');g.width=9;g.height=8;const gx=g.getContext('2d');gx.drawImage(b,0,0,9,8);const gd=gx.getImageData(0,0,9,8).data;let hs='';
 for(let y=0;y<8;y++)for(let q=0;q<8;q++)hs+=L(gd,(y*9+q)*4)>L(gd,(y*9+q+1)*4)?1:0;
 return{lap:s2/n-(s/n)**2,mean:m/(w*h),clip:e/(w*h),hs}}
const ham=(a,b)=>{let n=0;for(let i=0;i<64;i++)if(a[i]!=b[i])n++;return n};
async function run(files){
 files=[...files].filter(f=>f.type.startsWith('image/'));if(!files.length)return toast('Use JPG, PNG or WebP (export RAW to JPG first)');
 const R=[];for(let k=0;k<files.length;k++){const p=Math.round((k+1)/files.length*100);
  $('#un')&&($('#un').textContent=`Analysing ${k+1}/${files.length}: ${files[k].name}`);$('#ub')&&($('#ub').style.width=p+'%');$('#up')&&($('#up').textContent=p+'%');
  try{R.push(await an(files[k]))}catch{R.push({lap:0,mean:128,clip:1,hs:'1'.repeat(64)})}await new Promise(r=>setTimeout(r))}
 IMG.length=0;files.forEach(f=>IMG.push(URL.createObjectURL(f)));PH.length=0;RL.files=files;RL.on=1;S.gm={};
 R.forEach((r,i)=>{const sh=cl((Math.log10(r.lap+1)-1)/2.2),ex=cl(1-Math.abs(r.mean-118)/118-r.clip*2),why=[];
  if(sh<.35)why.push('soft or motion-blurred');if(r.mean<60)why.push('underexposed');if(r.mean>200)why.push('overexposed');if(r.clip>.15)why.push('clipped shadows/highlights');
  PH.push({i,s:0,sh,ex,n:files[i].name,h:r.hs,why:why.join(', ')||'sharp and well exposed'})});
 rescore();grp();DB.set.auto?decide():(S.keep=new Set,S.rej=new Set);await saveShoot();S.cur=0;go('workspace');render();toast(`Analysed ${files.length} photos on this device`);if(DB.set.gem)review(0,1)}
function decide(){S.keep=new Set;S.rej=new Set;PH.forEach(p=>((p.ai?p.ai=='keep':p.s>=DB.set.thr&&!p.dup)?S.keep:S.rej).add(p.i))}
document.addEventListener('change',e=>{if(e.target.id=='fi')run(e.target.files)});
document.addEventListener('drop',e=>{if(e.target.closest('#dz'))run(e.dataTransfer.files)});
document.addEventListener('click',async e=>{const a=e.target.closest('[data-act]');if(!a)return;const k=a.dataset.act;
 if(k=='auto'){decide();render();toast('Re-applied auto cull ')}
 if(k=='exp'){if(!RL.on)return toast('Upload photos first');RL.exp=1;const t='file,score,decision,reason\n'+PH.map(p=>`"${p.n}",${p.s},${S.keep.has(p.i)?'keep':'reject'},"${p.why}"`).join('\n'),u=URL.createObjectURL(new Blob([t],{type:'text/csv'})),l=document.createElement('a');l.href=u;l.download='cull-results.csv';l.click()}
 if(k=='gemma'){const p=PH[S.cur],el=$('#gm');el.textContent='Asking Gemma…';
  try{const r=await ask(p.i);S.gm[p.i]=r;el.textContent=r}catch{el.textContent='Ollama not reachable. Start it with: OLLAMA_ORIGINS=* ollama serve (see Local Models).'}}});
const fmt=d=>d.toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'});
const dl=(b,n)=>{const l=document.createElement('a');l.href=URL.createObjectURL(b);l.download=n;l.click()};
function rescore(){const w=DB.set.wsh/100;PH.forEach(p=>p.s=Math.round(100*(w*p.sh+(1-w)*p.ex)))}
function grp(){PH.forEach(p=>{if(p.w0==null)p.w0=p.why;p.dup=0;p.why=p.w0;p.dupOf=null});if(!DB.set.dd)return;
 PH.forEach((p,i)=>{for(let j=0;j<i;j++){const q=PH[j];if(!q.dup&&ham(p.h,q.h)<=DB.set.ham){const[lo,hi]=p.s>q.s?[q,p]:[p,q];lo.dup=1;lo.dupOf=hi.i;lo.why='near-duplicate of '+hi.n+(lo.w0.startsWith('sharp')?'':', '+lo.w0);break}}})}
async function saveShoot(){let th='';try{const b=await createImageBitmap(RL.files[0]),c=document.createElement('canvas');c.width=240;c.height=160;c.getContext('2d').drawImage(b,0,0,240,160);th=c.toDataURL('image/jpeg',.6)}catch{}
 const s={id:Date.now(),name:'Shoot '+fmt(new Date()),date:fmt(new Date()),n:PH.length,k:S.keep.size,r:S.rej.size,th};RL.sid=s.id;RL.rev=RL.exp=0;DB.shoots.unshift(s);DB.shoots.length=Math.min(DB.shoots.length,40);sv()}
const sync=()=>{const s=DB.shoots.find(x=>x.id==RL.sid);if(s&&RL.on){s.k=S.keep.size;s.r=S.rej.size;sv()}};
const empty=(k,t)=>shell(k,`${head(t,'')}<div class="card" style="text-align:center;padding:48px"><h3 style="font-size:28px">No photos loaded</h3><p class="mu" style="margin:8px 0 18px">Upload JPG/PNG/WebP photos to start culling. Photos stay in this browser tab.</p><button class="btn pri" data-go="upload">Upload photos</button></div>`);
[['workspace','Culling workspace'],['results','Results & export']].forEach(([k,t])=>{const o=PG[k];PG[k]=()=>RL.on?o():empty(k,t)});
const shRow=s=>`<div class="item shoot" data-n="${esc(s.name).toLowerCase()}"><div class="th">${s.th?`<img src="${s.th}" alt="">`:''}</div><div><b>${esc(s.name)}</b><div class="mu">${s.date} · ${s.n.toLocaleString()} photos</div></div><div class="sp"></div><div><b>${s.k}</b><div class="mu">Kept</div></div><div><b>${s.r}</b><div class="mu">Rejected</div></div><button class="btn sm" data-act="ren" data-id="${s.id}">Rename</button><button class="btn sm" data-act="del" data-id="${s.id}">Delete</button></div>`;
const none=`<div class="card" style="text-align:center;padding:40px"><h3 style="font-size:26px">No shoots yet</h3><p class="mu" style="margin:8px 0 16px">Each upload is saved here automatically.</p><button class="btn pri" data-go="upload">Upload photos</button></div>`;
PG.shoots=()=>shell('shoots',`${head('My Shoots','Saved on this device.','<button class="btn pri sm" data-go="upload">+ New shoot</button>')}${DB.shoots.length?`<div class="card list" id="sl" style="padding:6px">${DB.shoots.map(shRow).join('')}</div>`:none}`);
PG.dashboard=()=>{const q=DB.shoots,t=f=>q.reduce((a,s)=>a+s[f],0),h=new Date().getHours();
 return shell('dashboard',`${head(`Good ${h<12?'morning':h<18?'afternoon':'evening'}, ${esc(DB.user.name.split(' ')[0])}!`,'Here’s what’s happening with your shoots.')}<div class="grid g4">${stat('folder','Total shoots',q.length)}${stat('img','Total photos',t('n'))}${stat('bolt','Time saved (est. 6 s/photo)',Math.round(t('n')*6/60),' min')}${stat('ok','Kept photos',t('k'))}</div><div class="card row" id="aic" style="margin-top:16px">${ic('cpu')}<div><b>AI engine: ${esc(RL.model)} (open-weight, runs on this laptop)</b><div class="mu" id="ais">Checking Ollama…</div></div><div class="sp"></div><button class="btn sm" data-go="models">Local Models</button></div><div class="row" style="margin:24px 0 10px"><h3 style="font-size:24px">Recent shoots</h3><div class="sp"></div><button class="btn sm" data-go="shoots">View all</button></div>${q.length?`<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">${q.slice(0,4).map(s=>`<div class="card shoot" style="padding:10px"><div class="th">${s.th?`<img src="${s.th}" alt="">`:''}</div><b style="display:block;margin-top:8px">${esc(s.name)}</b><small class="mu">${s.n} photos · ${s.k} kept</small></div>`).join('')}</div>`:none}`)};
PG.pipeline=()=>{const on=RL.on,d=[on,on,on,RL.rev,RL.exp].map(Boolean),n=d.filter(Boolean).length,k=d.indexOf(false),st=d.map((v,i)=>v?'Completed':i==k?'In progress':'Pending'),dp=PH.filter(p=>p.dup).length;
 return shell('pipeline',`${head('Culling pipeline','Live status of the current shoot.')}<div class="card"><div class="steps">${[['up','Import','Photos'],['cpu','Analysis','Score & group'],['sl','Culling','Select best'],['ok','Review','Fine tune'],['dl','Export','Final set']].map(s=>`<div>${ic(s[0])}<b style="display:block;margin-top:8px">${s[1]}</b><small class="mu">${s[2]}</small></div>`).join('')}</div><div class="row" style="margin:24px 0 6px">Overall progress<div class="sp"></div>${n*20}%</div><div class="bar"><i data-w="${n*20}"></i></div></div><div class="grid g2" style="margin-top:16px"><div class="card"><h3 style="font-size:22px">Activity</h3>${['Import','Analysis','Culling','Review','Export'].map((a,i)=>`<div class="opt">${a}<span class="tag ${st[i]=='Completed'?'':'wip'}">${st[i]}</span></div>`).join('')}</div><div class="card"><h3 style="font-size:22px">Culling stats</h3><div class="opt">Total photos<b>${PH.length}</b></div><div class="opt">Kept<b>${S.keep.size}</b></div><div class="opt">Rejected<b>${S.rej.size}</b></div><div class="opt">Near-duplicates<b>${dp}</b></div><div class="opt">Gemma verdicts<b>${PH.filter(p=>p.ai).length}</b></div>${on?'':'<button class="btn pri w" style="margin-top:14px" data-go="upload">Upload photos</button>'}</div></div>`)};
async function aiStatus(){let ok=0;try{const m=(await(await fetch(DB.set.url+'/api/tags')).json()).models.map(x=>x.name);ok=m.some(x=>x==RL.model||x==RL.model+':latest')?2:1}catch{}
 const el=$('#ais');if(el)el.textContent=ok==2?`Connected. Gemma reviews borderline photos after every upload. AI verdicts this session: ${PH.filter(p=>p.ai).length}.`:ok==1?`Ollama is running but ${RL.model} is not installed. Run: ollama pull ${RL.model}`:'Ollama not running. Culling still works with the maths pass; start Ollama for AI verdicts.'}
{const o=PG.dashboard;PG.dashboard=()=>{const h=o();setTimeout(aiStatus);return h}}
const VM=['gemma3:4b','gemma3:12b','qwen2.5vl:7b','llava:7b'];
PG.models=()=>{setTimeout(async()=>{let inst=null;try{inst=(await(await fetch(DB.set.url+'/api/tags')).json()).models.map(m=>m.name)}catch{}
 const el=$('#ml');if(!el)return;$('#ms').textContent=inst?`Ollama connected · ${inst.length} model(s) installed`:`Ollama not reachable at ${DB.set.url}. Start it with: OLLAMA_ORIGINS=* ollama serve`;
 el.innerHTML=[...new Set([...VM,...(inst||[])])].map(m=>{const ok=inst&&inst.some(x=>x==m||x==m+':latest');return `<div class="card row">${ic('cpu')}<div><b>${esc(m)}</b><div class="mu">${ok?'Installed':'Not installed'}${m==RL.model?' · in use':''}</div></div><div class="sp"></div>${ok?`<button class="btn sm" data-act="use" data-id="${esc(m)}">${m==RL.model?'In use':'Use'}</button>`:`<button class="btn sm" data-act="cp" data-id="ollama pull ${esc(m)}">Copy pull command</button>`}</div>`}).join('')},0);
 return shell('models',`${head('Local models','Open-weight vision models served by your own Ollama.')}<p class="mu" id="ms" style="margin-bottom:14px">Checking Ollama…</p><div class="grid" id="ml"></div><p class="mu" style="margin-top:14px">Sharpness, exposure and duplicate detection need no model at all.</p>`)};
const sl=(l,k,mn,mx,d)=>`<label>${l} <output class="mu">${DB.set[k]}</output></label><input type="range" data-k="${k}" min="${mn}" max="${mx}" value="${DB.set[k]}"><small class="mu">${d}</small>`;
PG.filters=()=>shell('filters',`${head('Filters','Changes re-cull the current shoot instantly.')}<div class="grid g2"><div class="card"><h3 style="font-size:22px">Scoring</h3>${sl('Keep threshold','thr',30,90,'Photos scoring below this are rejected.')}${sl('Gemma review band (± score)','band',0,40,'Photos this close to the threshold go to Gemma.')}${sl('Sharpness weight (%)','wsh',0,100,'The rest goes to exposure.')}</div><div class="card"><h3 style="font-size:22px">Bursts</h3>${tgl('Reject near-duplicates',DB.set.dd,'Keeps only the best frame of each burst.').replace('class="tg','data-k="dd" class="tg')}${sl('Burst sensitivity','ham',2,20,'Higher groups looser matches.')}<p id="fc" class="mu" style="margin-top:16px"></p><button class="btn pri w" style="margin-top:12px" data-go="workspace">Open workspace</button></div></div>`);
PG.profile=()=>shell('profile',`${head('Profile','Stored only in this browser.')}<div class="card"><label>Full name</label><input class="in" id="pn" value="${esc(DB.user.name)}"><label>Email</label><input class="in" id="pe" value="${esc(DB.user.email)}"><button class="btn pri" style="margin-top:16px" data-act="psave">Save profile</button></div><div class="card" style="margin-top:16px"><div class="opt">Photos analysed<b>${DB.shoots.reduce((a,s)=>a+s.n,0)}</b></div><div class="opt">Licence<b>Free · MIT</b></div><p class="mu" style="margin-top:8px;font-size:12px">Cull has no account server, so nothing here leaves your device.</p></div>`);
PG.settings=()=>shell('settings',`${head('Settings','Saved on this device.')}<div class="grid g2"><div class="card"><h3 style="font-size:22px">Culling</h3>${tgl('Auto-cull on upload',DB.set.auto,'Off leaves every photo undecided.').replace('class="tg','data-k="auto" class="tg')}${tgl('Gemma reviews borderline photos',DB.set.gem,'Uses your local Ollama after the first pass.').replace('class="tg','data-k="gem" class="tg')}<label>Analysis resolution (px)</label><select class="in" data-k="res">${[128,256,512].map(v=>`<option ${v==DB.set.res?'selected':''}>${v}</option>`).join('')}</select><small class="mu">Higher is slower but catches finer blur.</small></div><div class="card"><h3 style="font-size:22px">Ollama / Gemma</h3><label>Ollama URL</label><input class="in" data-k="url" value="${esc(DB.set.url)}"><label>Critique prompt</label><textarea class="in" data-k="prompt" rows="4">${esc(DB.set.prompt)}</textarea><button class="btn w" style="margin-top:16px" data-act="reset">Reset all local data</button></div></div>`);
const ov=h=>{const d=document.createElement('div');d.style.cssText='position:fixed;inset:0;z-index:99;background:#000e;display:flex;gap:12px;align-items:center;justify-content:center;padding:16px;cursor:zoom-out';d.innerHTML=h;d.onclick=()=>d.remove();document.body.append(d)};
const fig=p=>`<figure style="flex:1;min-width:0;text-align:center"><img src="${P(p.i)}" style="max-width:100%;max-height:80vh"><figcaption>${esc(p.n)} · score ${p.s}</figcaption></figure>`;
document.addEventListener('click',async e=>{const a=e.target.closest('[data-act]'),t=e.target.closest('.tg[data-k]');if(t){DB.set[t.dataset.k]=+t.classList.contains('on');sv();if(RL.on&&t.dataset.k=='dd'){grp();decide()}}
 if(!a)return;const k=a.dataset.act,p=PH[S.cur];
 if(k=='keep'||k=='rej')RL.rev=1;
 if(k=='rv')review(0);
 if(k=='src'){const i=document.createElement('input'),x=[...a.parentNode.children].indexOf(a);i.type='file';i.multiple=true;i.accept='image/*';if(x==0)i.capture='environment';if(x==2)i.webkitdirectory=true;i.onchange=()=>run(i.files);i.click()}
 if(k=='zm')ov(`<img src="${P(p.i)}" style="max-width:100%;max-height:100%">`);
 if(k=='cmp')ov(fig(p)+fig(PH[p.dupOf!=null?p.dupOf:(S.cur+1)%PH.length]));
 if(k=='zip'){if(!RL.on)return toast('Upload photos first');const f=PH.filter(q=>S.keep.has(q.i)).map(q=>RL.files[q.i]);if(!f.length)return toast('No kept photos');toast('Building zip…');RL.exp=1;dl(await makeZip(f),'cull-keepers.zip')}
 if(k=='use'){RL.model=DB.set.model=a.dataset.id;sv();render()}
 if(k=='cp'){try{await navigator.clipboard.writeText(a.dataset.id);toast('Copied: '+a.dataset.id)}catch{toast(a.dataset.id)}}
 if(k=='psave'){DB.user={name:$('#pn').value.trim()||'Photographer',email:$('#pe').value.trim()};sv();render();toast('Profile saved')}
 if(k=='ren'){const s=DB.shoots.find(x=>x.id==a.dataset.id),v=prompt('Shoot name',s.name);if(v&&v.trim()){s.name=v.trim().slice(0,60);sv();render()}}
 if(k=='del'){DB.shoots=DB.shoots.filter(x=>x.id!=a.dataset.id);sv();render()}
 if(k=='reset'&&confirm('Delete saved shoots, profile and settings?')){try{localStorage.removeItem('cull')}catch{}location.hash='';location.reload()}
 setTimeout(sync)});
document.addEventListener('keydown',e=>{if(location.hash=='#/workspace'&&'kx'.includes(e.key.toLowerCase()))RL.rev=1;setTimeout(sync)});
document.addEventListener('input',e=>{const k=e.target.dataset.k;if(!k||e.target.classList.contains('tg'))return;const r=e.target.type=='range'||k=='res';DB.set[k]=r?+e.target.value:e.target.value;
 if(k=='url')DB.set.url=DB.set.url.replace(/\/+$/,'');sv();const o=e.target.previousElementSibling;if(r&&o&&o.querySelector('output'))o.querySelector('output').textContent=e.target.value;
 if(r&&RL.on&&k!='res'){rescore();grp();decide();sync()}if(r&&$('#fc'))$('#fc').textContent=RL.on?`Current shoot: ${S.keep.size} kept, ${S.rej.size} rejected.`:''});
document.addEventListener('change',e=>{if(e.target.id=='sp')$('#ap').type=e.target.checked?'text':'password'});
document.addEventListener('click',e=>{if(e.target.closest('[data-act="atab"]'))setTimeout(()=>{const x=$('#aerr');if(x)x.textContent=''})});
const hp=async(p,s)=>{try{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s+p));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}catch{return btoa(unescape(encodeURIComponent(s+p)))}};
document.addEventListener('submit',async e=>{if(e.target.id!='af')return;e.preventDefault();const t=e.target.dataset.t||'in',er=m=>($('#aerr').textContent=m),nm=$('#an').value.trim(),em=$('#ae').value.trim().toLowerCase(),pw=$('#ap').value;
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em))return er('Enter a valid email, for example name123@gmail.com');
 if(t=='fg')return er(DB.acct&&DB.acct.email==em?'There is no server to email you. Use Settings → Reset all local data, then create a new account.':'No account with that email on this device.');
 if(pw.length<6)return er('Password must be at least 6 characters. Letters, numbers and symbols are all allowed.');
 if(t=='up'){if(nm.length<2)return er('Enter your name.');if(DB.acct&&DB.acct.email==em)return er('That account already exists. Use Sign in.');const s=Math.random().toString(36).slice(2);DB.acct={email:em,salt:s,hash:await hp(pw,s)};DB.user={name:nm,email:em};sv();toast('Account created');}
 else{if(!DB.acct)return er('No account on this device yet. Choose Create account.');if(DB.acct.email!=em||DB.acct.hash!=await hp(pw,DB.acct.salt))return er('Wrong email or password.');DB.user.email=em;sv();toast('Welcome back');}
 er('');setTimeout(()=>go('dashboard'),400)});

async function ask(i){const b=await createImageBitmap(RL.files[i]),c=document.createElement('canvas');c.width=Math.min(768,b.width);c.height=Math.round(b.height*c.width/b.width);c.getContext('2d').drawImage(b,0,0,c.width,c.height);
 const r=await fetch(DB.set.url+'/api/generate',{method:'POST',body:JSON.stringify({model:RL.model,stream:false,prompt:DB.set.prompt,images:[c.toDataURL('image/jpeg',.8).split(',')[1]]})});return(await r.json()).response||''}
async function review(all,quiet){if(!RL.on)return toast('Upload photos first');const t=DB.set.thr,L=PH.filter(p=>!p.ai&&(all||Math.abs(p.s-t)<=DB.set.band));
 if(!L.length)return quiet||toast('No borderline photos to review');
 try{await fetch(DB.set.url+'/api/tags')}catch{return quiet||toast('Ollama not reachable. See the Models page.')}
 let n=0;for(const p of L){toast(`Gemma reviewing ${++n}/${L.length}…`);
  try{const a=await ask(p.i),m=a.match(/KEEP|REJECT/gi);S.gm[p.i]=a;if(m){const kp=m[m.length-1].toUpperCase()=='KEEP';p.ai=kp?'keep':'reject';(kp?S.rej:S.keep).delete(p.i);(kp?S.keep:S.rej).add(p.i);p.why='Gemma says '+p.ai+'. '+p.why}}catch{toast('Gemma request failed. Check the Models page.');break}
  sync();if(['#/workspace','#/results'].includes(location.hash))render()}
 toast(`Gemma reviewed ${PH.filter(p=>p.ai).length} photo(s)`)}
})();

;['dragover','drop'].forEach(n=>document.addEventListener(n,e=>{if(e.target.closest('#dz')){e.preventDefault();$('#dz').classList.toggle('hv',n=='dragover')}}));
