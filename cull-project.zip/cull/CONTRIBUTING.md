# Contributing

Cull is plain HTML, CSS and JavaScript with no build step.

1. Fork and clone the repo, then open the folder in VS Code.
2. Serve it: `npm start` (or Live Server on `index.html`).
3. Before opening a pull request run `npm run check` and `npm test`.

Good first issues: RAW preview support, XMP sidecar export for Lightroom, more unit tests for scoring and burst grouping, trying other open vision models.
