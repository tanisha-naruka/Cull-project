# Cull

**Local-first photo culling with an open-weight AI judge.** Drop in a shoot and Cull sorts it into keepers and rejects on your own machine. Photos are never uploaded, and there is no server or account backend.

Built for the Hacktoberfest Open-Source AI challenge (Side Hustle week).

## Why
Photographers come home with thousands of frames and spend hours choosing which to keep. Hosted AI cullers need the whole shoot uploaded, which many clients' privacy terms do not allow. Cull keeps everything on the laptop, and because the model is open-weight it costs nothing per image.

## Features
- **Fast first pass:** sharpness, exposure and burst detection in the browser, with adjustable weights and threshold
- **Gemma as the judge:** photos near the keep threshold go to **Gemma 3** (via your own Ollama), which answers KEEP or REJECT. That verdict overrides the score. Without Ollama the app still works on the first pass alone
- **AI is visible everywhere:** the workspace has a Gemma AI panel (verdict text, AI badge on the photo, AI verdict count), and the dashboard shows whether the Gemma engine is connected
- **Review workspace:** K / X to keep or reject, arrow keys to move, zoom, and compare against the best frame of a burst, with a plain-English reason for every decision
- **Export:** ZIP of kept originals, or CSV of every decision
- **Local state:** shoots, profile and settings saved in the browser; a Models page lists what your Ollama has installed

## Quick start
```bash
git clone <your-repo-url> && cd cull
npm start            # or: python -m http.server 5500
```
Open http://localhost:5500 and upload JPG/PNG/WebP photos. In VS Code you can instead right-click `index.html` and choose **Open with Live Server**.

### Enable the Gemma judge
```bash
ollama pull gemma3:4b
# allow the browser to call Ollama, then restart it
OLLAMA_ORIGINS=* ollama serve          # macOS/Linux
$env:OLLAMA_ORIGINS="*"; ollama serve  # Windows PowerShell
```
Open **Models** in the app: it should say "Ollama connected". Other vision models (`gemma3:12b`, `qwen2.5vl:7b`, `llava:7b`) can be selected there.

## Project structure
```
cull/
├── index.html
├── css/styles.css
├── js/app.js        UI: router, pages, components
├── js/zip.js        ZIP writer (tested)
├── js/cull.js       engine: analysis, scoring, bursts, Gemma review, settings, shoots
├── assets/          favicon, hero and sample images
├── tests/           unit tests (npm test)
├── docs/HOW_IT_WORKS.md
├── .github/workflows/ci.yml
└── .vscode/         Live Server and Chrome debug config
```
See [docs/HOW_IT_WORKS.md](docs/HOW_IT_WORKS.md) for the scoring method, privacy details and limits.

## Scripts
| Command | What it does |
|---|---|
| `npm start` | Serve the folder on port 5500 |
| `npm run check` | Syntax-check all scripts |
| `npm test` | Run unit tests (Node 22+) |

## Deploy
Static site. On Render choose **Static Site** with publish directory `.` (see `render.yaml`). It also works on DigitalOcean App Platform or GitHub Pages. The Gemma judge only works for visitors running Ollama locally.

## Limits
JPG/PNG/WebP only; photos live in memory for the session; accuracy has not been benchmarked. Details in the docs.

## License
MIT
