const test = require('node:test');
const assert = require('node:assert');
const zlib = require('node:zlib');
const { makeZip } = require('../js/zip.js');

test('makeZip writes a valid archive with correct CRCs and entry count', async () => {
  const files = [new File([Buffer.from('hello world')], 'a.txt'), new File([Buffer.alloc(5000, 7)], 'b.jpg')];
  const buf = Buffer.from(await (await makeZip(files)).arrayBuffer());
  assert.equal(buf.readUInt32LE(0), 0x04034b50, 'local header signature');
  const eocd = buf.length - 22;
  assert.equal(buf.readUInt32LE(eocd), 0x06054b50, 'end-of-central-directory signature');
  assert.equal(buf.readUInt16LE(eocd + 10), 2, 'entry count');
  assert.equal(buf.readUInt32LE(14), zlib.crc32(Buffer.from('hello world')), 'crc of first file');
});
